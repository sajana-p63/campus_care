# Campus Care — corrected development version

## Main corrections
- Added student registration, login, logout, and a profile page.
- Public registration always creates a `student` role. It cannot grant admin or technician access.
- Complaint pages require login.
- Students can submit complaints and only see complaints owned by their account.
- Admin/staff users can review all complaints; technicians see assigned and unassigned work.
- Complaint ownership is assigned from the authenticated session, never from form input.
- Replaced the broken `title` ModelForm field with the actual `subject` model field.
- Validated form fields server-side and corrected the category value mismatch.
- Added ticket IDs with a UUID-derived suffix.
- Registered the custom user model using Django's `UserAdmin`.
- Added access and registration tests.
- Excluded the local virtual environment, bytecode caches, and local SQLite database from this archive.

## Run on Windows
Open PowerShell in the folder containing `manage.py` (the `campus_care` folder).

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open `http://127.0.0.1:8000/`. New users can register at `/accounts/register/`.
The Django admin is at `/admin/`.

To make a technician account, create/register the account first, then use the admin site to change its role to `technician`. To create an admin-role dashboard account, change its role to `admin`. Only trusted staff should be allowed into `/admin/`; set `is_staff` for accounts that need Django admin access. A superuser created with `createsuperuser` can access Django admin.

## Run tests
```powershell
python manage.py check
python manage.py test
```

## Existing database note
This archive intentionally does not include `db.sqlite3`. Run migrations to create a fresh local database. If you have existing data you need, back up your database before replacing project files and run migrations against that database.

## Production warning
The settings defaults are for local development only. Before deployment, set `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=0`, and `DJANGO_ALLOWED_HOSTS` to the real hostnames. Configure HTTPS, secure cookies, database backups, and any email settings required by your deployment.
