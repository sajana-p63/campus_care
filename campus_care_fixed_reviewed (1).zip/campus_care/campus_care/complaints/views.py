import uuid

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import IntegrityError, transaction
from django.shortcuts import redirect, render
from django.utils import timezone

from .forms import ComplaintForm
from .models import Complaint


def is_management_user(user):
    return user.is_authenticated and (
        user.is_superuser or user.is_staff or user.role == "admin"
    )


@login_required
def complaint_home(request):
    """
    Students may submit complaints and see only their own records.
    Admins can review all records. Technicians see assigned and unassigned
    work items. The server, not the submitted form, determines ownership.
    """
    user = request.user

    if request.method == "POST":
        if user.role != "student":
            raise PermissionDenied("Only student accounts can submit complaints.")

        form = ComplaintForm(request.POST)
        if form.is_valid():
            # Use a random token to avoid predictable ticket IDs and collisions.
            ticket_id = None
            for _ in range(5):
                candidate = f"CMP-{timezone.localdate():%Y}-{uuid.uuid4().hex[:10].upper()}"
                if not Complaint.objects.filter(ticket_id=candidate).exists():
                    ticket_id = candidate
                    break

            if ticket_id is None:
                messages.error(request, "Could not create a ticket ID. Please try again.")
                return redirect("complaint_home")

            try:
                with transaction.atomic():
                    complaint = form.save(commit=False)
                    complaint.student = user
                    complaint.ticket_id = ticket_id
                    complaint.status = "Submitted"
                    complaint.save()
            except IntegrityError:
                messages.error(request, "Ticket creation conflicted. Please try again.")
                return redirect("complaint_home")

            messages.success(request, f"Complaint submitted. Your ticket ID is {complaint.ticket_id}.")
            return redirect("complaint_home")
    else:
        form = ComplaintForm()

    complaints = Complaint.objects.select_related("student", "assigned_to").order_by("-created_at")
    if is_management_user(user):
        # Staff/administrators can review all complaints.
        pass
    elif user.role == "technician":
        complaints = complaints.filter(assigned_to=user) | complaints.filter(assigned_to__isnull=True)
        complaints = complaints.distinct().order_by("-created_at")
    else:
        complaints = complaints.filter(student=user)

    return render(request, "complaints/index.html", {
        "complaints": complaints,
        "form": form,
        "is_management_user": is_management_user(user),
    })
