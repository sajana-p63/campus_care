from rest_framework import serializers # type: ignore
from .models import Complaint, User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'role', 'department']

class ComplaintSerializer(serializers.ModelSerializer):
    student_name = serializers.ReadOnlyField(source='student.username')
    assigned_technician = serializers.ReadOnlyField(source='assigned_to.username')

    class Meta:
        model = Complaint
        fields = '__all__'