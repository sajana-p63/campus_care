from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import Complaint, User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ("username", "email", "role", "department", "is_staff", "is_active")
    list_filter = ("role", "is_staff", "is_active")
    fieldsets = BaseUserAdmin.fieldsets + (
        ("Campus profile", {"fields": ("role", "department")}),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ("Campus profile", {"fields": ("role", "department", "email")}),
    )


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = (
        "ticket_id", "subject", "category", "priority", "status",
        "student", "assigned_to", "created_at",
    )
    list_filter = ("status", "category", "priority")
    search_fields = ("ticket_id", "subject", "description", "student__username")
    readonly_fields = ("ticket_id", "created_at", "updated_at")
    list_select_related = ("student", "assigned_to")
