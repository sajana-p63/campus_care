from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Complaint

User = get_user_model()


class ComplaintAccessTests(TestCase):
    def setUp(self):
        self.student = User.objects.create_user(
            username="student1", password="Test-pass-123", role="student"
        )
        self.other_student = User.objects.create_user(
            username="student2", password="Test-pass-123", role="student"
        )
        self.own_complaint = Complaint.objects.create(
            student=self.student, ticket_id="CMP-TEST-OWN",
            subject="My issue", category="IT", description="A sufficiently detailed issue."
        )
        self.other_complaint = Complaint.objects.create(
            student=self.other_student, ticket_id="CMP-TEST-OTHER",
            subject="Private issue", category="Hostel", description="Another detailed issue."
        )

    def test_anonymous_user_is_redirected_to_login(self):
        response = self.client.get(reverse("complaint_home"))
        self.assertRedirects(response, f"{reverse('login')}?next={reverse('complaint_home')}")

    def test_student_sees_only_own_complaints(self):
        self.client.force_login(self.student)
        response = self.client.get(reverse("complaint_home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "My issue")
        self.assertNotContains(response, "Private issue")

    def test_student_can_submit_complaint(self):
        self.client.force_login(self.student)
        response = self.client.post(reverse("complaint_home"), {
            "subject": "Broken projector",
            "category": "IT",
            "location": "Room 101",
            "contact_phone": "",
            "description": "The projector is not working in the lecture room.",
            "priority": "High",
        })
        self.assertRedirects(response, reverse("complaint_home"))
        complaint = Complaint.objects.get(subject="Broken projector")
        self.assertEqual(complaint.student, self.student)
        self.assertTrue(complaint.ticket_id.startswith("CMP-"))

    def test_invalid_category_is_rejected(self):
        self.client.force_login(self.student)
        response = self.client.post(reverse("complaint_home"), {
            "subject": "Bad category", "category": "Ragging/Harassment",
            "location": "Room 1", "contact_phone": "",
            "description": "This description is long enough.",
            "priority": "Medium",
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Complaint.objects.filter(subject="Bad category").exists())

    def test_admin_role_can_review_all_complaints(self):
        admin_user = User.objects.create_user(
            username="campusadmin", password="Test-pass-123", role="admin"
        )
        self.client.force_login(admin_user)
        response = self.client.get(reverse("complaint_home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "My issue")
        self.assertContains(response, "Private issue")
