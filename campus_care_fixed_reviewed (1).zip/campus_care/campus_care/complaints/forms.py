from django import forms
from .models import Complaint


class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = (
            "subject",
            "category",
            "location",
            "contact_phone",
            "description",
            "priority",
        )
        widgets = {
            "subject": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Brief title of the problem",
                "maxlength": 200,
            }),
            "category": forms.Select(attrs={"class": "form-select"}),
            "location": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Building, hostel, room, or area",
                "maxlength": 150,
            }),
            "contact_phone": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Contact phone (optional)",
                "maxlength": 20,
            }),
            "description": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 5,
                "placeholder": "Describe the issue clearly",
            }),
            "priority": forms.Select(attrs={"class": "form-select"}),
        }

    def clean_subject(self):
        subject = self.cleaned_data["subject"].strip()
        if not subject:
            raise forms.ValidationError("Please enter a subject.")
        return subject

    def clean_description(self):
        description = self.cleaned_data["description"].strip()
        if len(description) < 10:
            raise forms.ValidationError("Please provide at least 10 characters of detail.")
        return description
