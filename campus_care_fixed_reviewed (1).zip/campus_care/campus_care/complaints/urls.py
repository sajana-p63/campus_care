from django.urls import path
from . import views

urlpatterns = [
    path('', views.complaint_home, name='complaint_home'),
]