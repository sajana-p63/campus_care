from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

User = get_user_model()


class RegistrationTests(TestCase):
    def test_registration_creates_student_not_admin(self):
        response = self.client.post(reverse("register"), {
            "username": "newstudent",
            "first_name": "New",
            "last_name": "Student",
            "email": "student@example.com",
            "department": "Computer Science",
            "password1": "A-long-unique-pass-2026!",
            "password2": "A-long-unique-pass-2026!",
        })
        self.assertRedirects(response, reverse("complaint_home"))
        user = User.objects.get(username="newstudent")
        self.assertEqual(user.role, "student")
        self.assertFalse(user.is_staff)
        self.assertTrue(user.check_password("A-long-unique-pass-2026!"))
